import unittest
import pandas as pd
import numpy as np
from neatdata.neatdata import *

class TestYCleaner(unittest.TestCase):

    def testYCleaner_EmptyTest(self):
        pass
