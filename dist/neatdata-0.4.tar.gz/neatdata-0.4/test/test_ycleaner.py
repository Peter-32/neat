import unittest
import pandas as pd
import numpy as np
from neatdata.y.ycleaner import *
from neatdata.numpyhelper.numpyhelper import *

class TestYCleaner(unittest.TestCase):

    def testYCleaner_EmptyTest(self):
        pass
