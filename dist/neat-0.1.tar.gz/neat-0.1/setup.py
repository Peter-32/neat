from distutils.core import setup
setup(
  name = 'neat',
  packages = ['neat'], # this must be the same as the name above
  version = '0.1',
  description = 'Cleaning code',
  long_description='Cleans a dataset following the strategy described here: http://data-in-model-out.com/2018/01/07/understand-data-cleaning/',
  author = 'Peter Myers',
  author_email = 'peterjmyers1@gmail.com',
  url = 'https://github.com/Peter-32/neat', # use the URL to the github repo
  download_url = 'https://github.com/Peter-32/neatbook/archive/0.11.tar.gz', # I'll explain this in a second
  keywords = ['automated machine learning', 'cleaning', 'classification', 'code generation'],
  classifiers = [
  'Development Status :: 3 - Alpha',
'Topic :: Scientific/Engineering :: Artificial Intelligence',
'License :: OSI Approved :: MIT License',
'Programming Language :: Python :: 3',
'Programming Language :: Python :: 3.2',
'Programming Language :: Python :: 3.3',
'Programming Language :: Python :: 3.4',
'Programming Language :: Python :: 3.5',
'Programming Language :: Python :: 3.6',
  ],
  install_requires=['nbformat', 'sklearn', 'numpy', 'pandas'],
  python_requires='>=3',
  license='MIT'
)
